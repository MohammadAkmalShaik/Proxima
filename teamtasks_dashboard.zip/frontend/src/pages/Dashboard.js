import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useDropzone } from 'react-dropzone';
import {
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  LayoutDashboard, Users, ListTodo, MessageSquare,
  Lightbulb, Upload, Send, TrendingUp, AlertTriangle,
  Clock, Activity, FileText, Target, Award
} from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from '../components/ui/sonner';
import EnhancedOverview from '../components/EnhancedOverview';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const COLORS = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe'];

export default function Dashboard({ user, token, onLogout }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [overview, setOverview] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [insights, setInsights] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    assigned_to: '',
    priority: ''
  });

  // Settings state
  const [settings, setSettings] = useState({
    name: user.name,
    email: user.email,
    notifications: true,
    darkMode: false
  });

  // Axios config with auth token
  const axiosConfig = {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  };

  // Fetch Overview
  const fetchOverview = async () => {
    try {
      const response = await axios.get(`${API}/overview`, axiosConfig);
      setOverview(response.data);
    } catch (error) {
      console.error('Error fetching overview:', error);
      if (error.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        onLogout();
      } else {
        toast.error('Failed to load overview');
      }
    }
  };

  // Save Settings
  const saveSettings = async () => {
    toast.success('Settings saved successfully!');
  };

  // Fetch Tasks
  const fetchTasks = async () => {
    try {
      const params = {};
      if (filters.status) params.status = filters.status;
      if (filters.assigned_to) params.assigned_to = filters.assigned_to;
      if (filters.priority) params.priority = filters.priority;

      const response = await axios.get(`${API}/tasks`, { ...axiosConfig, params });
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      if (error.response?.status === 401) {
        onLogout();
      } else {
        toast.error('Failed to load tasks');
      }
    }
  };

  // Fetch Insights
  const fetchInsights = async () => {
    try {
      const response = await axios.get(`${API}/insights`, axiosConfig);
      setInsights(response.data);
    } catch (error) {
      console.error('Error fetching insights:', error);
      if (error.response?.status === 401) {
        onLogout();
      }
    }
  };

  // Generate Insights
  const generateInsights = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API}/insights/generate`, {}, axiosConfig);
      setInsights(response.data.insights);
      toast.success('Insights generated successfully!');
    } catch (error) {
      console.error('Error generating insights:', error);
      if (error.response?.status === 401) {
        onLogout();
      } else {
        toast.error('Failed to generate insights');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle File Upload
  const onDrop = useCallback(async (acceptedFiles) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    setLoading(true);
    try {
      const response = await axios.post(`${API}/upload`, formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        }
      });
      toast.success(response.data.message);
      
      // Refresh data
      await fetchOverview();
      await fetchTasks();
      
      // Auto-generate insights after upload if enabled
      if (settings.autoInsights !== false) {
        toast.info('Generating AI insights automatically...');
        setTimeout(() => {
          generateInsights();
        }, 1000);
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      if (error.response?.status === 401) {
        onLogout();
      } else {
        toast.error('Failed to upload dataset');
      }
    } finally {
      setLoading(false);
    }
  }, [token, settings]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'] },
    multiple: false
  });

  // Send Chat Message
  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = { role: 'user', content: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');

    try {
      const response = await axios.post(`${API}/chat`, {
        message: chatInput,
        session_id: 'default'
      }, axiosConfig);

      const assistantMessage = { role: 'assistant', content: response.data.response };
      setChatMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      if (error.response?.status === 401) {
        onLogout();
      } else {
        toast.error('Failed to send message');
      }
    }
  };

  useEffect(() => {
    fetchOverview();
    fetchTasks();
    fetchInsights();
  }, []);

  // Auto-generate insights when AI Insights tab is opened
  useEffect(() => {
    if (activeTab === 'insights' && insights.length === 0 && !loading && overview && overview.total_tasks > 0) {
      console.log('Auto-generating insights on tab open...');
      generateInsights();
    }
  }, [activeTab]);

  useEffect(() => {
    fetchTasks();
  }, [filters]);

  const renderEnhancedOverview = () => {
    if (!overview) return <div className="loading"><div className="spinner"></div></div>;

    return (
      <div data-testid="overview-section">
        <EnhancedOverview overview={overview} tasks={tasks} />
      </div>
    );
  };

  const renderSettings = () => (
    <div data-testid="settings-section">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))', gap: '2rem' }}>
        
        {/* Profile Information */}
        <div className="content-section">
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Users size={20} style={{ color: '#667eea' }} />
            Profile Information
          </h3>
          
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Name
            </label>
            <input
              type="text"
              value={settings.name}
              onChange={(e) => setSettings({ ...settings, name: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                transition: 'border-color 0.3s ease'
              }}
              onFocus={(e) => e.target.style.borderColor = '#667eea'}
              onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Email
            </label>
            <input
              type="email"
              value={settings.email}
              disabled
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                background: '#f8fafc',
                color: '#64748b',
                cursor: 'not-allowed'
              }}
            />
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
              Email cannot be changed
            </p>
          </div>

          <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: '12px' }}>
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>Member Since</p>
            <p style={{ fontSize: '1rem', fontWeight: 600, color: '#1a2332' }}>
              {new Date(user.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
        </div>

        {/* Notifications & Alerts */}
        <div className="content-section">
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertTriangle size={20} style={{ color: '#667eea' }} />
            Notifications & Alerts
          </h3>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {/* Smart Alerts Toggle */}
            <label style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '1rem',
              background: '#f8fafc',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'background 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#f8fafc'}
            >
              <div>
                <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Smart Alerts</div>
                <div style={{ fontSize: '0.813rem', color: '#64748b' }}>Get notified about anomalies and performance issues</div>
              </div>
              <input
                type="checkbox"
                checked={settings.notifications}
                onChange={(e) => setSettings({ ...settings, notifications: e.target.checked })}
                style={{ width: '20px', height: '20px', cursor: 'pointer' }}
              />
            </label>

            {/* Task Completion Alerts */}
            <label style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '1rem',
              background: '#f8fafc',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'background 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#f8fafc'}
            >
              <div>
                <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Task Completion Alerts</div>
                <div style={{ fontSize: '0.813rem', color: '#64748b' }}>Notify when team members complete tasks</div>
              </div>
              <input
                type="checkbox"
                checked={settings.taskAlerts || true}
                onChange={(e) => setSettings({ ...settings, taskAlerts: e.target.checked })}
                style={{ width: '20px', height: '20px', cursor: 'pointer' }}
              />
            </label>

            {/* Velocity Changes */}
            <label style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '1rem',
              background: '#f8fafc',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'background 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#f8fafc'}
            >
              <div>
                <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Velocity Changes</div>
                <div style={{ fontSize: '0.813rem', color: '#64748b' }}>Alert on significant velocity changes (±20%)</div>
              </div>
              <input
                type="checkbox"
                checked={settings.velocityAlerts || false}
                onChange={(e) => setSettings({ ...settings, velocityAlerts: e.target.checked })}
                style={{ width: '20px', height: '20px', cursor: 'pointer' }}
              />
            </label>

            {/* Sentiment Warnings */}
            <label style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '1rem',
              background: '#f8fafc',
              borderRadius: '12px',
              cursor: 'pointer',
              transition: 'background 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#f8fafc'}
            >
              <div>
                <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Team Sentiment Warnings</div>
                <div style={{ fontSize: '0.813rem', color: '#64748b' }}>Alert when team morale drops below threshold</div>
              </div>
              <input
                type="checkbox"
                checked={settings.sentimentAlerts || false}
                onChange={(e) => setSettings({ ...settings, sentimentAlerts: e.target.checked })}
                style={{ width: '20px', height: '20px', cursor: 'pointer' }}
              />
            </label>
          </div>
        </div>

        {/* Dashboard Preferences */}
        <div className="content-section">
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <LayoutDashboard size={20} style={{ color: '#667eea' }} />
            Dashboard Preferences
          </h3>
          
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Data Refresh Interval
            </label>
            <select
              value={settings.refreshInterval || '30'}
              onChange={(e) => setSettings({ ...settings, refreshInterval: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                cursor: 'pointer',
                background: 'white'
              }}
            >
              <option value="10">Real-time (10 seconds)</option>
              <option value="30">30 seconds</option>
              <option value="60">1 minute</option>
              <option value="300">5 minutes</option>
            </select>
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
              How often to refresh dashboard data
            </p>
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Default Chart Type
            </label>
            <select
              value={settings.chartType || 'all'}
              onChange={(e) => setSettings({ ...settings, chartType: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                cursor: 'pointer',
                background: 'white'
              }}
            >
              <option value="all">Show All Charts</option>
              <option value="essential">Essential Only</option>
              <option value="detailed">Detailed View</option>
            </select>
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Theme
            </label>
            <select
              value={settings.theme || 'light'}
              onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                cursor: 'pointer',
                background: 'white'
              }}
            >
              <option value="light">Light Mode</option>
              <option value="dark">Dark Mode (Coming Soon)</option>
            </select>
          </div>

          <div style={{ background: '#eef2ff', padding: '1rem', borderRadius: '12px', border: '2px solid #c7d2fe' }}>
            <p style={{ fontSize: '0.813rem', color: '#4338ca', fontWeight: 500 }}>
              💡 <strong>Pro Tip:</strong> Enable real-time refresh for live monitoring during sprints
            </p>
          </div>
        </div>

        {/* AI & Analytics Settings */}
        <div className="content-section">
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Lightbulb size={20} style={{ color: '#667eea' }} />
            AI & Analytics
          </h3>
          
          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Anomaly Detection Sensitivity
            </label>
            <select
              value={settings.anomalySensitivity || 'medium'}
              onChange={(e) => setSettings({ ...settings, anomalySensitivity: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                cursor: 'pointer',
                background: 'white'
              }}
            >
              <option value="low">Low (±30% deviation)</option>
              <option value="medium">Medium (±20% deviation)</option>
              <option value="high">High (±10% deviation)</option>
            </select>
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
              How sensitive the anomaly detection should be
            </p>
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, color: '#1a2332', fontSize: '0.875rem' }}>
              Forecast Horizon
            </label>
            <select
              value={settings.forecastDays || '7'}
              onChange={(e) => setSettings({ ...settings, forecastDays: e.target.value })}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                border: '2px solid #e2e8f0',
                borderRadius: '12px',
                fontSize: '1rem',
                cursor: 'pointer',
                background: 'white'
              }}
            >
              <option value="3">3 days</option>
              <option value="7">1 week</option>
              <option value="14">2 weeks</option>
              <option value="30">1 month</option>
            </select>
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
              Time range for predictive forecasting
            </p>
          </div>

          <label style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '1rem',
            background: '#f8fafc',
            borderRadius: '12px',
            cursor: 'pointer',
            transition: 'background 0.3s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
          onMouseLeave={(e) => e.currentTarget.style.background = '#f8fafc'}
          >
            <div>
              <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Auto-Generate Insights</div>
              <div style={{ fontSize: '0.813rem', color: '#64748b' }}>Automatically generate insights on data upload</div>
            </div>
            <input
              type="checkbox"
              checked={settings.autoInsights || false}
              onChange={(e) => setSettings({ ...settings, autoInsights: e.target.checked })}
              style={{ width: '20px', height: '20px', cursor: 'pointer' }}
            />
          </label>
        </div>

        {/* Account Statistics */}
        <div className="content-section">
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Activity size={20} style={{ color: '#667eea' }} />
            Account Statistics
          </h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem', marginBottom: '1rem' }}>
            <div style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', padding: '1.5rem', borderRadius: '12px', color: 'white' }}>
              <p style={{ fontSize: '0.75rem', marginBottom: '0.5rem', opacity: 0.9 }}>Total Tasks</p>
              <p style={{ fontSize: '2rem', fontWeight: 700, margin: 0 }}>
                {overview ? overview.total_tasks : 0}
              </p>
            </div>
            <div style={{ background: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)', padding: '1.5rem', borderRadius: '12px', color: 'white' }}>
              <p style={{ fontSize: '0.75rem', marginBottom: '0.5rem', opacity: 0.9 }}>Completed</p>
              <p style={{ fontSize: '2rem', fontWeight: 700, margin: 0 }}>
                {overview ? overview.closed_tasks : 0}
              </p>
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: '1.5rem', borderRadius: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Completion Rate</span>
              <span style={{ fontSize: '1.25rem', fontWeight: 700, color: '#667eea' }}>
                {overview ? ((overview.closed_tasks / overview.total_tasks * 100) || 0).toFixed(1) : 0}%
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Avg Completion Time</span>
              <span style={{ fontSize: '1.25rem', fontWeight: 700, color: '#4facfe' }}>
                {overview ? overview.avg_completion_time : 0}h
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.875rem', color: '#64748b' }}>Productivity Score</span>
              <span style={{ fontSize: '1.25rem', fontWeight: 700, color: '#43e97b' }}>
                {overview ? (overview.avg_ai_usage * 100).toFixed(0) : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={saveSettings}
        style={{
          marginTop: '2rem',
          padding: '1rem 2rem',
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontWeight: 600,
          cursor: 'pointer',
          fontSize: '1rem',
          boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)',
          transition: 'all 0.3s ease',
          display: 'inline-flex',
          alignItems: 'center',
          gap: '0.5rem'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'translateY(-2px)';
          e.currentTarget.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.3)';
        }}
      >
        <Target size={18} />
        Save All Settings
      </button>
    </div>
  );

  const renderTasks = () => {
    const uniqueStatuses = [...new Set(tasks.map(t => t.status))];
    const uniqueMembers = [...new Set(tasks.map(t => t.assigned_to))];
    const uniquePriorities = [...new Set(tasks.map(t => t.priority))];

    return (
      <div data-testid="tasks-section">
        <div className="filters">
          <select
            className="filter-select"
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            data-testid="status-filter"
          >
            <option value="">All Status</option>
            {uniqueStatuses.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
          <select
            className="filter-select"
            value={filters.assigned_to}
            onChange={(e) => setFilters({ ...filters, assigned_to: e.target.value })}
            data-testid="member-filter"
          >
            <option value="">All Members</option>
            {uniqueMembers.map(member => (
              <option key={member} value={member}>{member}</option>
            ))}
          </select>
          <select
            className="filter-select"
            value={filters.priority}
            onChange={(e) => setFilters({ ...filters, priority: e.target.value })}
            data-testid="priority-filter"
          >
            <option value="">All Priorities</option>
            {uniquePriorities.map(priority => (
              <option key={priority} value={priority}>{priority}</option>
            ))}
          </select>
        </div>

        <div className="table-container">
          <table data-testid="tasks-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th>Priority</th>
                <th>Created</th>
                <th>Completion Time</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task, index) => (
                <tr key={index} data-testid={`task-row-${task.task_id}`}>
                  <td>{task.task_id}</td>
                  <td style={{ fontWeight: 600 }}>{task.title}</td>
                  <td>{task.assigned_to}</td>
                  <td>
                    <span className={`status-badge ${task.status.toLowerCase().replace(' ', '-')}`}>
                      {task.status}
                    </span>
                  </td>
                  <td>
                    <span className={`priority-badge ${task.priority.toLowerCase()}`}>
                      {task.priority}
                    </span>
                  </td>
                  <td>{task.created_at}</td>
                  <td>{task.completion_time_hours ? `${task.completion_time_hours}h` : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {tasks.length === 0 && (
          <div className="empty-state" data-testid="empty-tasks">
            <FileText size={64} />
            <p style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.5rem' }}>No tasks found</p>
            <p style={{ fontSize: '0.875rem' }}>Upload a dataset to see your tasks</p>
          </div>
        )}
      </div>
    );
  };

  const renderChat = () => (
    <div data-testid="chat-section">
      <div className="chat-container">
        <div className="chat-messages" data-testid="chat-messages">
          {chatMessages.length === 0 && (
            <div className="empty-state">
              <MessageSquare size={64} />
              <p style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.5rem' }}>Start a conversation</p>
              <p style={{ fontSize: '0.875rem' }}>Ask me anything about your team's productivity and tasks</p>
            </div>
          )}
          {chatMessages.map((msg, index) => (
            <div
              key={index}
              className={`chat-message ${msg.role}`}
              data-testid={`chat-message-${msg.role}`}
            >
              {msg.content}
            </div>
          ))}
        </div>
        <div className="chat-input-area">
          <input
            type="text"
            className="chat-input"
            placeholder="Ask about team productivity, tasks, or insights..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
            data-testid="chat-input"
          />
          <button className="btn-primary" onClick={sendChatMessage} data-testid="send-button">
            <Send size={20} />
            Send
          </button>
        </div>
      </div>
    </div>
  );

  const renderInsights = () => {
    // Icon mapping for insight types
    const getInsightIcon = (type) => {
      switch(type) {
        case 'velocity': return <TrendingUp size={24} style={{ color: '#667eea' }} />;
        case 'forecast': return <Target size={24} style={{ color: '#4facfe' }} />;
        case 'anomaly': return <AlertTriangle size={24} style={{ color: '#f5576c' }} />;
        case 'sentiment': return <Activity size={24} style={{ color: '#43e97b' }} />;
        case 'benchmark': return <Award size={24} style={{ color: '#f093fb' }} />;
        default: return <Lightbulb size={24} style={{ color: '#667eea' }} />;
      }
    };

    const getInsightColor = (type) => {
      switch(type) {
        case 'velocity': return '#667eea';
        case 'forecast': return '#4facfe';
        case 'anomaly': return '#f5576c';
        case 'sentiment': return '#43e97b';
        case 'benchmark': return '#f093fb';
        default: return '#667eea';
      }
    };

    return (
      <div data-testid="insights-section">
        <div style={{ 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          padding: '1.5rem 2rem',
          borderRadius: '16px',
          marginBottom: '2rem',
          color: 'white',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '0.5rem', margin: 0 }}>
              Advanced AI Insights
            </h3>
            <p style={{ fontSize: '0.875rem', opacity: 0.9, margin: 0 }}>
              Velocity tracking, forecasting, anomaly detection, sentiment analysis & benchmarking
            </p>
          </div>
          <button
            onClick={generateInsights}
            disabled={loading}
            data-testid="generate-insights-button"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem 1.5rem',
              background: 'rgba(255, 255, 255, 0.2)',
              color: 'white',
              border: '2px solid rgba(255, 255, 255, 0.3)',
              borderRadius: '12px',
              fontWeight: 600,
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s ease',
              backdropFilter: 'blur(10px)'
            }}
            onMouseEnter={(e) => {
              if (!loading) {
                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.5)';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
              e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
            }}
          >
            <Lightbulb size={20} />
            {loading ? 'Generating...' : 'Generate Insights'}
          </button>
        </div>

        <div className="insights-grid">
          {insights.map((insight, index) => (
            <div
              key={index}
              className="insight-card"
              data-testid={`insight-card-${insight.type}`}
              style={{
                background: 'white',
                borderLeft: `4px solid ${getInsightColor(insight.type)}`,
                borderRadius: '16px',
                padding: '1.5rem',
                boxShadow: '0 4px 16px rgba(0, 0, 0, 0.06)',
                transition: 'all 0.3s ease'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                {getInsightIcon(insight.type)}
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.25rem', margin: 0 }}>
                    {insight.title}
                  </h3>
                  <span style={{
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    textTransform: 'uppercase',
                    color: getInsightColor(insight.type),
                    letterSpacing: '0.5px'
                  }}>
                    {insight.type}
                  </span>
                </div>
              </div>
              <p style={{ lineHeight: 1.7, color: '#475569', fontSize: '0.938rem', whiteSpace: 'pre-line' }}>
                {insight.content}
              </p>
              
              {/* Display key metrics if available */}
              {insight.data && (
                <div style={{
                  marginTop: '1rem',
                  paddingTop: '1rem',
                  borderTop: '1px solid #e2e8f0',
                  display: 'flex',
                  gap: '1rem',
                  flexWrap: 'wrap'
                }}>
                  {Object.entries(insight.data).slice(0, 3).map(([key, value]) => (
                    typeof value !== 'object' && (
                      <div key={key} style={{ fontSize: '0.813rem' }}>
                        <span style={{ color: '#64748b', fontWeight: 500 }}>
                          {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}:
                        </span>
                        <span style={{ marginLeft: '0.25rem', fontWeight: 600, color: '#1a2332' }}>
                          {typeof value === 'number' ? value : String(value)}
                        </span>
                      </div>
                    )
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {insights.length === 0 && !loading && (
          <div className="empty-state" data-testid="empty-insights">
            <Lightbulb size={64} />
            <p style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.5rem' }}>
              Auto-Generating Insights...
            </p>
            <p style={{ fontSize: '0.875rem', maxWidth: '500px', margin: '0 auto', color: '#667eea' }}>
              AI is analyzing your data to generate velocity analysis, forecasting, anomaly detection, sentiment analysis, and team benchmarking
            </p>
            <p style={{ fontSize: '0.75rem', marginTop: '1rem', color: '#64748b' }}>
              This may take 10-15 seconds...
            </p>
          </div>
        )}

        {loading && (
          <div style={{ textAlign: 'center', padding: '3rem' }}>
            <div className="spinner" style={{ margin: '0 auto 1rem' }}></div>
            <p style={{ color: '#667eea', fontWeight: 600, fontSize: '1.125rem', marginBottom: '0.5rem' }}>
              Analyzing data and generating advanced insights...
            </p>
            <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
              Please wait while AI analyzes your team's productivity data
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="dashboard-container">
      <div className="sidebar">
        <div className="sidebar-logo">
          <LayoutDashboard size={28} />
          Dashboard
        </div>
        
        <div style={{
          padding: '0 2rem',
          marginBottom: '2rem',
          paddingBottom: '1.5rem',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <div style={{ fontSize: '0.875rem', color: 'rgba(255, 255, 255, 0.6)', marginBottom: '0.25rem' }}>
            Logged in as
          </div>
          <div style={{ color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>
            {user.name}
          </div>
          <div style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '0.75rem' }}>
            {user.email}
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <div
            className={`sidebar-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
            data-testid="nav-overview"
          >
            <LayoutDashboard size={20} />
            Overview
          </div>
          <div
            className={`sidebar-item ${activeTab === 'tasks' ? 'active' : ''}`}
            onClick={() => setActiveTab('tasks')}
            data-testid="nav-tasks"
          >
            <ListTodo size={20} />
            Tasks
          </div>
          <div
            className={`sidebar-item ${activeTab === 'queries' ? 'active' : ''}`}
            onClick={() => setActiveTab('queries')}
            data-testid="nav-queries"
          >
            <MessageSquare size={20} />
            Queries
          </div>
          <div
            className={`sidebar-item ${activeTab === 'insights' ? 'active' : ''}`}
            onClick={() => setActiveTab('insights')}
            data-testid="nav-insights"
          >
            <Lightbulb size={20} />
            AI Insights
          </div>
          <div
            className={`sidebar-item ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
            data-testid="nav-settings"
          >
            <Users size={20} />
            Settings
          </div>
        </nav>
        
        <div style={{ position: 'absolute', bottom: '2rem', left: 0, right: 0, padding: '0 2rem' }}>
          <button
            onClick={onLogout}
            style={{
              width: '100%',
              padding: '0.75rem',
              background: 'rgba(255, 255, 255, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              borderRadius: '12px',
              color: 'white',
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.target.style.background = 'rgba(255, 255, 255, 0.15)';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'rgba(255, 255, 255, 0.1)';
            }}
          >
            Logout
          </button>
        </div>
      </div>

      <div className="main-content">
        <div className="dashboard-header">
          <div>
            <h1 className="dashboard-title" data-testid="dashboard-title">
              {activeTab === 'overview' && 'Dashboard Overview'}
              {activeTab === 'settings' && 'Settings'}
              {activeTab === 'tasks' && 'Task Management'}
              {activeTab === 'queries' && 'AI Queries'}
              {activeTab === 'insights' && 'AI Insights'}
            </h1>
            <p className="dashboard-subtitle">
              {activeTab === 'overview' && 'Monitor productivity and track performance metrics'}
              {activeTab === 'settings' && 'Manage your account and preferences'}
              {activeTab === 'tasks' && 'View and filter all tasks'}
              {activeTab === 'queries' && 'Ask AI about your data'}
              {activeTab === 'insights' && 'AI-powered predictions and analysis'}
            </p>
          </div>
          
          {/* Fixed Upload Button */}
          <div {...getRootProps()} data-testid="upload-zone" style={{ cursor: 'pointer' }}>
            <input {...getInputProps()} data-testid="file-input" />
            <button
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.75rem 1.5rem',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontWeight: 600,
                fontSize: '0.875rem',
                cursor: 'pointer',
                boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)',
                transition: 'all 0.3s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.3)';
              }}
            >
              <Upload size={18} />
              Upload Dataset
            </button>
          </div>
        </div>

        <div className="content-section">
          {activeTab === 'overview' && renderEnhancedOverview()}
          {activeTab === 'settings' && renderSettings()}
          {activeTab === 'tasks' && renderTasks()}
          {activeTab === 'queries' && renderChat()}
          {activeTab === 'insights' && renderInsights()}
        </div>
      </div>
    </div>
  );
}
