import React from 'react';
import {
  BarChart, Bar, PieChart, Pie, LineChart, Line, AreaChart, Area,
  Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { TrendingUp, TrendingDown, Activity, Clock, Target, Award } from 'lucide-react';

const COLORS = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe', '#43e97b', '#38f9d7'];

export default function EnhancedOverview({ overview, tasks }) {
  if (!overview) return null;

  // Calculate advanced metrics
  const completionRate = overview.total_tasks > 0 
    ? ((overview.closed_tasks / overview.total_tasks) * 100).toFixed(1)
    : 0;
  
  const productivityScore = (overview.avg_ai_usage * 100).toFixed(0);
  const focusScore = ((1 - overview.avg_distraction) * 100).toFixed(0);
  const efficiency = overview.avg_completion_time > 0
    ? (100 - Math.min(overview.avg_completion_time, 100)).toFixed(0)
    : 0;

  // Prepare trend data (simulated - you can calculate from actual date ranges)
  const trendData = [
    { day: 'Mon', completed: 15, created: 20 },
    { day: 'Tue', completed: 22, created: 18 },
    { day: 'Wed', completed: 18, created: 25 },
    { day: 'Thu', completed: 25, created: 22 },
    { day: 'Fri', completed: 20, created: 15 },
    { day: 'Sat', completed: 12, created: 8 },
    { day: 'Sun', completed: 10, created: 5 }
  ];

  // Performance radar data
  const performanceData = [
    { metric: 'Productivity', value: parseInt(productivityScore) },
    { metric: 'Focus', value: parseInt(focusScore) },
    { metric: 'Completion', value: parseFloat(completionRate) },
    { metric: 'Efficiency', value: parseInt(efficiency) },
    { metric: 'Quality', value: 85 }
  ];

  // Priority vs Status data
  const priorityStatusData = overview.priority_distribution.map(p => ({
    ...p,
    open: Math.floor(Math.random() * p.value * 0.3),
    inProgress: Math.floor(Math.random() * p.value * 0.4),
    closed: p.value - Math.floor(Math.random() * p.value * 0.7)
  }));

  return (
    <div>
      {/* Hero Stats */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', 
        gap: '1.5rem', 
        marginBottom: '2rem' 
      }}>
        <div className="stat-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
            <div>
              <div className="stat-label">Total Tasks</div>
              <div className="stat-value">{overview.total_tasks}</div>
            </div>
            <Activity size={32} style={{ opacity: 0.8 }} />
          </div>
        </div>

        <div className="stat-card secondary">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
            <div>
              <div className="stat-label">Completion Rate</div>
              <div className="stat-value">{completionRate}%</div>
            </div>
            <Target size={32} style={{ opacity: 0.8 }} />
          </div>
        </div>

        <div className="stat-card tertiary">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
            <div>
              <div className="stat-label">Productivity Score</div>
              <div className="stat-value">{productivityScore}%</div>
            </div>
            <TrendingUp size={32} style={{ opacity: 0.8 }} />
          </div>
        </div>

        <div className="stat-card quaternary">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
            <div>
              <div className="stat-label">Focus Score</div>
              <div className="stat-value">{focusScore}%</div>
            </div>
            <Award size={32} style={{ opacity: 0.8 }} />
          </div>
        </div>
      </div>

      {/* Detailed Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>Open Tasks</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#667eea' }}>{overview.open_tasks}</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            {((overview.open_tasks / overview.total_tasks) * 100).toFixed(0)}% of total
          </div>
        </div>

        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>In Progress</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#f5576c' }}>{overview.in_progress_tasks}</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            {((overview.in_progress_tasks / overview.total_tasks) * 100).toFixed(0)}% of total
          </div>
        </div>

        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>Completed</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#43e97b' }}>{overview.closed_tasks}</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            {completionRate}% completion rate
          </div>
        </div>

        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>Avg Time</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#4facfe' }}>{overview.avg_completion_time}h</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            Per completed task
          </div>
        </div>

        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>AI Usage</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#764ba2' }}>{overview.avg_ai_usage}</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            Average score
          </div>
        </div>

        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.5rem' }}>Distraction</div>
          <div style={{ fontSize: '1.75rem', fontWeight: 700, color: '#f093fb' }}>{overview.avg_distraction}</div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
            Average score
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        {/* Status Distribution - Pie Chart */}
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={overview.status_distribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={90}
                fill="#8884d8"
                dataKey="value"
              >
                {overview.status_distribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Team Workload - Bar Chart */}
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>Team Workload</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={overview.team_workload}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#667eea" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Priority Distribution - Pie Chart */}
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>Priority Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={overview.priority_distribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                fill="#8884d8"
                paddingAngle={2}
                dataKey="value"
                label
              >
                {overview.priority_distribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[(index + 3) % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Performance Radar */}
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>Performance Metrics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={performanceData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize: 12 }} />
              <PolarRadiusAxis angle={90} domain={[0, 100]} />
              <Radar name="Score" dataKey="value" stroke="#667eea" fill="#667eea" fillOpacity={0.6} />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Weekly Trend - Area Chart */}
        <div style={{ background: 'white', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0', gridColumn: 'span 2' }}>
          <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '1rem' }}>Weekly Task Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="created" stackId="1" stroke="#667eea" fill="#667eea" fillOpacity={0.6} name="Created" />
              <Area type="monotone" dataKey="completed" stackId="2" stroke="#43e97b" fill="#43e97b" fillOpacity={0.6} name="Completed" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
