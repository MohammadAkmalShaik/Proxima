from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import pandas as pd
import io
from emergentintegrations.llm.chat import LlmChat, UserMessage
import asyncio
import jwt
from passlib.context import CryptContext
import math

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key-change-this')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Pydantic Models
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Token(BaseModel):
    access_token: str
    token_type: str
    user: User

class Task(BaseModel):
    model_config = ConfigDict(extra="ignore")
    task_id: int
    title: str
    assigned_to: str
    status: str
    priority: str
    created_at: str
    closed_at: Optional[str] = None
    comments: str
    ai_usage_score: float
    distraction_score: float
    completion_time_hours: Optional[float] = None

class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    role: str
    content: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = "default"

class AIInsight(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: str
    title: str
    content: str
    data: Dict[str, Any]
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Helper Functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0, "password": 0})
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Could not validate credentials")

# Auth Routes
@api_router.post("/auth/register", response_model=Token)
async def register(user_data: UserRegister):
    """
    Register a new user
    """
    try:
        # Check if user exists
        existing_user = await db.users.find_one({"email": user_data.email})
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Create user
        user = User(
            email=user_data.email,
            name=user_data.name
        )
        
        user_dict = user.model_dump()
        user_dict['password'] = hash_password(user_data.password)
        user_dict['created_at'] = user_dict['created_at'].isoformat()
        
        await db.users.insert_one(user_dict)
        
        # Create access token
        access_token = create_access_token(
            data={"sub": user.id},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        
        return Token(access_token=access_token, token_type="bearer", user=user)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error registering user: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/auth/login", response_model=Token)
async def login(user_data: UserLogin):
    """
    Login user
    """
    try:
        # Find user
        user_doc = await db.users.find_one({"email": user_data.email})
        if not user_doc or not verify_password(user_data.password, user_doc['password']):
            raise HTTPException(status_code=401, detail="Incorrect email or password")
        
        # Create access token
        access_token = create_access_token(
            data={"sub": user_doc['id']},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        
        user = User(
            id=user_doc['id'],
            email=user_doc['email'],
            name=user_doc['name'],
            created_at=datetime.fromisoformat(user_doc['created_at']) if isinstance(user_doc['created_at'], str) else user_doc['created_at']
        )
        
        return Token(access_token=access_token, token_type="bearer", user=user)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error logging in: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/auth/me", response_model=User)
async def get_me(current_user: dict = Depends(get_current_user)):
    """
    Get current user info
    """
    return User(**current_user)

# Routes
@api_router.get("/")
async def root():
    return {"message": "Dashboard API is running"}

@api_router.post("/upload")
async def upload_dataset(file: UploadFile = File(...), current_user: dict = Depends(get_current_user)):
    """
    Upload CSV file and replace existing tasks for this user
    """
    try:
        contents = await file.read()
        df = pd.read_csv(io.BytesIO(contents))
        
        # Replace NaN values
        df = df.replace({pd.NA: None, pd.NaT: None})
        df = df.where(pd.notnull(df), None)
        
        # Convert to list of dicts and add user_id
        tasks_data = df.to_dict('records')
        for task in tasks_data:
            task['user_id'] = current_user['id']
        
        # Clear existing tasks for this user
        await db.tasks.delete_many({"user_id": current_user['id']})
        
        # Insert new tasks
        if tasks_data:
            await db.tasks.insert_many(tasks_data)
        
        return {
            "success": True,
            "message": f"Successfully uploaded {len(tasks_data)} tasks",
            "count": len(tasks_data)
        }
    except Exception as e:
        logger.error(f"Error uploading dataset: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.get("/overview")
async def get_overview(current_user: dict = Depends(get_current_user)):
    """
    Get overview metrics for the dashboard
    """
    try:
        tasks = await db.tasks.find({"user_id": current_user['id']}, {"_id": 0}).to_list(10000)
        
        if not tasks:
            return {
                "total_tasks": 0,
                "open_tasks": 0,
                "in_progress_tasks": 0,
                "closed_tasks": 0,
                "avg_completion_time": 0,
                "avg_ai_usage": 0,
                "avg_distraction": 0,
                "status_distribution": [],
                "priority_distribution": [],
                "team_workload": []
            }
        
        df = pd.DataFrame(tasks)
        
        total_tasks = len(df)
        status_counts = df['status'].value_counts().to_dict()
        priority_counts = df['priority'].value_counts().to_dict()
        team_counts = df['assigned_to'].value_counts().to_dict()
        
        closed_df = df[df['status'] == 'Closed']
        avg_completion = closed_df['completion_time_hours'].mean() if len(closed_df) > 0 else 0
        
        return {
            "total_tasks": total_tasks,
            "open_tasks": status_counts.get('Open', 0),
            "in_progress_tasks": status_counts.get('In Progress', 0),
            "closed_tasks": status_counts.get('Closed', 0),
            "avg_completion_time": round(avg_completion, 2) if avg_completion else 0,
            "avg_ai_usage": round(df['ai_usage_score'].mean(), 2),
            "avg_distraction": round(df['distraction_score'].mean(), 2),
            "status_distribution": [{"name": k, "value": v} for k, v in status_counts.items()],
            "priority_distribution": [{"name": k, "value": v} for k, v in priority_counts.items()],
            "team_workload": [{"name": k, "value": v} for k, v in team_counts.items()]
        }
    except Exception as e:
        logger.error(f"Error fetching overview: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/team-performance")
async def get_team_performance(current_user: dict = Depends(get_current_user)):
    """
    Get team member performance metrics
    """
    try:
        tasks = await db.tasks.find({"user_id": current_user['id']}, {"_id": 0}).to_list(10000)
        
        if not tasks:
            return []
        
        df = pd.DataFrame(tasks)
        
        team_stats = []
        for member in df['assigned_to'].unique():
            member_df = df[df['assigned_to'] == member]
            closed_tasks = member_df[member_df['status'] == 'Closed']
            
            team_stats.append({
                "name": member,
                "total_tasks": len(member_df),
                "completed_tasks": len(closed_tasks),
                "in_progress": len(member_df[member_df['status'] == 'In Progress']),
                "open_tasks": len(member_df[member_df['status'] == 'Open']),
                "avg_completion_time": round(closed_tasks['completion_time_hours'].mean(), 2) if len(closed_tasks) > 0 else 0,
                "avg_ai_usage": round(member_df['ai_usage_score'].mean(), 2),
                "avg_distraction": round(member_df['distraction_score'].mean(), 2),
                "completion_rate": round((len(closed_tasks) / len(member_df)) * 100, 1) if len(member_df) > 0 else 0
            })
        
        return team_stats
    except Exception as e:
        logger.error(f"Error fetching team performance: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/tasks")
async def get_tasks(
    status: Optional[str] = None,
    assigned_to: Optional[str] = None,
    priority: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    """
    Get all tasks with optional filtering
    """
    try:
        query = {"user_id": current_user['id']}
        if status:
            query['status'] = status
        if assigned_to:
            query['assigned_to'] = assigned_to
        if priority:
            query['priority'] = priority
        
        tasks = await db.tasks.find(query, {"_id": 0}).to_list(10000)
        
        # Convert NaN values to None
        for task in tasks:
            for key, value in task.items():
                if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                    task[key] = None
        
        return tasks
    except Exception as e:
        logger.error(f"Error fetching tasks: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/chat")
async def chat(request: ChatRequest, current_user: dict = Depends(get_current_user)):
    """
    AI Chatbot endpoint
    """
    try:
        tasks = await db.tasks.find({"user_id": current_user['id']}, {"_id": 0}).to_list(10000)
        df = pd.DataFrame(tasks) if tasks else pd.DataFrame()
        
        context = "You are an AI assistant helping with a productivity dashboard. "
        if not df.empty:
            context += f"\n\nCurrent Dashboard Data:\n"
            context += f"- Total Tasks: {len(df)}\n"
            context += f"- Status Distribution: {df['status'].value_counts().to_dict()}\n"
            context += f"- Team Members: {', '.join(df['assigned_to'].unique())}\n"
            context += f"- Priority Distribution: {df['priority'].value_counts().to_dict()}\n"
            context += f"- Average AI Usage Score: {df['ai_usage_score'].mean():.2f}\n"
            context += f"- Average Distraction Score: {df['distraction_score'].mean():.2f}\n"
        
        context += "\n\nAnswer questions about the team's productivity, tasks, and provide insights."
        
        chat_client = LlmChat(
            api_key=os.environ.get('EMERGENT_LLM_KEY'),
            session_id=f"{current_user['id']}_{request.session_id}",
            system_message=context
        ).with_model("gemini", "gemini-2.5-pro")
        
        user_message = UserMessage(text=request.message)
        response = await chat_client.send_message(user_message)
        
        user_msg = ChatMessage(role="user", content=request.message)
        assistant_msg = ChatMessage(role="assistant", content=response)
        
        await db.chat_history.insert_one({
            **user_msg.model_dump(),
            "timestamp": user_msg.timestamp.isoformat(),
            "session_id": request.session_id,
            "user_id": current_user['id']
        })
        await db.chat_history.insert_one({
            **assistant_msg.model_dump(),
            "timestamp": assistant_msg.timestamp.isoformat(),
            "session_id": request.session_id,
            "user_id": current_user['id']
        })
        
        return {
            "response": response,
            "session_id": request.session_id
        }
    except Exception as e:
        logger.error(f"Error in chat: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/insights")
async def get_insights(current_user: dict = Depends(get_current_user)):
    """
    Get AI-generated insights
    """
    try:
        insights = await db.insights.find({"user_id": current_user['id']}, {"_id": 0}).to_list(100)
        
        for insight in insights:
            if isinstance(insight.get('timestamp'), str):
                insight['timestamp'] = datetime.fromisoformat(insight['timestamp'])
        
        return insights
    except Exception as e:
        logger.error(f"Error fetching insights: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/insights/generate")
async def generate_insights(current_user: dict = Depends(get_current_user)):
    """
    Generate Advanced AI insights - Hackathon Edition
    """
    try:
        tasks = await db.tasks.find({"user_id": current_user['id']}, {"_id": 0}).to_list(10000)
        
        if not tasks:
            raise HTTPException(status_code=400, detail="No tasks available for analysis")
        
        df = pd.DataFrame(tasks)
        
        chat_client = LlmChat(
            api_key=os.environ.get('EMERGENT_LLM_KEY'),
            session_id=f"{current_user['id']}_insights",
            system_message="You are an expert AI analyst for team productivity dashboards. Provide data-driven, actionable insights with specific metrics and recommendations."
        ).with_model("gemini", "gemini-2.5-pro")
        
        insights = []
        
        # 1. VELOCITY & EFFICIENCY ANALYSIS (Hackathon Requirement)
        closed_tasks = df[df['status'] == 'Closed']
        if len(closed_tasks) > 0:
            avg_completion = closed_tasks['completion_time_hours'].mean()
            velocity = len(closed_tasks)
            efficiency = (1 - df['distraction_score'].mean()) * 100
            
            velocity_prompt = f"""Analyze team velocity and efficiency metrics:

**Performance Metrics:**
- Total Closed Tasks: {velocity}
- Average Completion Time: {avg_completion:.1f} hours
- Team Efficiency Score: {efficiency:.1f}%
- AI Tool Usage: {df['ai_usage_score'].mean():.2f}
- Distraction Score: {df['distraction_score'].mean():.2f}

**Task Distribution:**
- High Priority Closed: {len(closed_tasks[closed_tasks['priority'] == 'High'])}
- Medium Priority Closed: {len(closed_tasks[closed_tasks['priority'] == 'Medium'])}
- Low Priority Closed: {len(closed_tasks[closed_tasks['priority'] == 'Low'])}

Provide a velocity analysis with:
1. Current velocity trend
2. Efficiency improvement recommendations
3. Specific metric: "Velocity increased/decreased by X%"
(3-4 sentences)"""
            
            velocity_response = await chat_client.send_message(UserMessage(text=velocity_prompt))
            
            insights.append(AIInsight(
                type="velocity",
                title="Team Velocity & Efficiency Analysis",
                content=velocity_response,
                data={
                    "velocity": velocity,
                    "avg_completion_time": round(avg_completion, 2),
                    "efficiency_score": round(efficiency, 1),
                    "ai_usage": round(df['ai_usage_score'].mean(), 2)
                }
            ))
        
        # 2. WORKLOAD PREDICTION & FORECASTING (AI Differentiator)
        open_in_progress = df[df['status'].isin(['Open', 'In Progress'])]
        if len(open_in_progress) > 0:
            forecast_prompt = f"""Predict workload completion and provide forecasting insights:

**Current Workload:**
- Pending Tasks: {len(open_in_progress)}
- Average Task Complexity (AI Usage): {open_in_progress['ai_usage_score'].mean():.2f}
- Team Distraction Level: {open_in_progress['distraction_score'].mean():.2f}
- Priority Breakdown: {open_in_progress['priority'].value_counts().to_dict()}

**Historical Performance:**
- Completed Tasks: {len(closed_tasks)}
- Avg Completion Time: {closed_tasks['completion_time_hours'].mean():.1f}h (if any)

Using predictive analysis:
1. Estimate completion timeline for pending tasks
2. Identify high-risk delayed tasks
3. Provide a specific forecast: "Expected completion in X days with Y% confidence"
4. Recommend resource allocation
(4-5 sentences)"""
            
            forecast_response = await chat_client.send_message(UserMessage(text=forecast_prompt))
            
            insights.append(AIInsight(
                type="forecast",
                title="Workload Forecasting & Predictive Analysis",
                content=forecast_response,
                data={
                    "pending_tasks": len(open_in_progress),
                    "high_priority_pending": len(open_in_progress[open_in_progress['priority'] == 'High']),
                    "forecast_complexity": round(open_in_progress['ai_usage_score'].mean(), 2)
                }
            ))
        
        # 3. ANOMALY DETECTION (Smart Alerts)
        anomaly_prompt = f"""Detect anomalies and unusual patterns in team productivity:

**Team Performance Data:**
"""
        for member in df['assigned_to'].unique():
            member_df = df[df['assigned_to'] == member]
            member_closed = member_df[member_df['status'] == 'Closed']
            avg_time = member_closed['completion_time_hours'].mean() if len(member_closed) > 0 else 0
            
            anomaly_prompt += f"""
- {member}:
  * Total Tasks: {len(member_df)}
  * Completed: {len(member_closed)}
  * In Progress: {len(member_df[member_df['status'] == 'In Progress'])}
  * Avg Completion: {avg_time:.1f}h
  * AI Usage: {member_df['ai_usage_score'].mean():.2f}
  * Distraction: {member_df['distraction_score'].mean():.2f}
"""
        
        anomaly_prompt += """
Identify:
1. Performance outliers (very high/low completion times)
2. Task overload patterns (too many in-progress)
3. Efficiency drops (high distraction, low AI usage)
4. Provide specific alert: "ALERT: [Member] shows X% deviation"
(3-4 sentences with actionable alerts)"""
        
        anomaly_response = await chat_client.send_message(UserMessage(text=anomaly_prompt))
        
        insights.append(AIInsight(
            type="anomaly",
            title="Anomaly Detection & Smart Alerts",
            content=anomaly_response,
            data={
                "team_stats": [
                    {
                        "member": member,
                        "total": len(df[df['assigned_to'] == member]),
                        "in_progress": len(df[(df['assigned_to'] == member) & (df['status'] == 'In Progress')]),
                        "distraction": round(df[df['assigned_to'] == member]['distraction_score'].mean(), 2)
                    }
                    for member in df['assigned_to'].unique()
                ]
            }
        ))
        
        # 4. TEAM SENTIMENT & MORALE ANALYSIS
        sentiment_prompt = f"""Analyze team sentiment and morale based on productivity indicators:

**Productivity Indicators:**
- Overall Team Size: {len(df['assigned_to'].unique())} members
- Average AI Tool Adoption: {df['ai_usage_score'].mean():.2f}
- Average Distraction Score: {df['distraction_score'].mean():.2f}
- Task Completion Rate: {(len(closed_tasks) / len(df) * 100):.1f}%
- High Priority Task Handling: {len(df[df['priority'] == 'High'])} tasks

**Workload Distribution:**
{df['assigned_to'].value_counts().to_dict()}

Provide sentiment analysis:
1. Overall team morale (Positive/Neutral/Negative)
2. Stress indicators from distraction scores
3. Team collaboration quality from AI usage
4. Specific insight: "Team morale is [X] based on [metrics]"
(3-4 sentences)"""
        
        sentiment_response = await chat_client.send_message(UserMessage(text=sentiment_prompt))
        
        insights.append(AIInsight(
            type="sentiment",
            title="Team Sentiment & Morale Analysis",
            content=sentiment_response,
            data={
                "team_size": len(df['assigned_to'].unique()),
                "completion_rate": round((len(closed_tasks) / len(df) * 100), 1),
                "avg_distraction": round(df['distraction_score'].mean(), 2),
                "morale_indicator": "positive" if df['distraction_score'].mean() < 0.4 else "neutral"
            }
        ))
        
        # 5. COMPARATIVE BENCHMARKING (Team Ranking)
        benchmark_prompt = f"""Provide comparative team benchmarking and rankings:

**Team Member Performance:**
"""
        team_metrics = []
        for member in df['assigned_to'].unique():
            member_df = df[df['assigned_to'] == member]
            member_closed = member_df[member_df['status'] == 'Closed']
            completion_rate = (len(member_closed) / len(member_df) * 100) if len(member_df) > 0 else 0
            
            team_metrics.append({
                "member": member,
                "total": len(member_df),
                "completed": len(member_closed),
                "rate": completion_rate
            })
            
            benchmark_prompt += f"""
- {member}:
  * Completion Rate: {completion_rate:.1f}%
  * Tasks Completed: {len(member_closed)}/{len(member_df)}
  * AI Efficiency: {member_df['ai_usage_score'].mean():.2f}
"""
        
        # Sort by completion rate
        team_metrics.sort(key=lambda x: x['rate'], reverse=True)
        
        benchmark_prompt += """
Provide:
1. Performance ranking (Top performers)
2. Efficiency comparison between team members
3. Recommendations for underperformers
4. Specific metric: "Top performer: [Name] with X% completion rate"
(3-4 sentences)"""
        
        benchmark_response = await chat_client.send_message(UserMessage(text=benchmark_prompt))
        
        insights.append(AIInsight(
            type="benchmark",
            title="Team Performance Benchmarking",
            content=benchmark_response,
            data={
                "rankings": team_metrics[:3],  # Top 3
                "top_performer": team_metrics[0]['member'] if team_metrics else "N/A"
            }
        ))
        
        # Clear old insights and save new
        await db.insights.delete_many({"user_id": current_user['id']})
        for insight in insights:
            insight_dict = insight.model_dump()
            insight_dict['timestamp'] = insight_dict['timestamp'].isoformat()
            insight_dict['user_id'] = current_user['id']
            await db.insights.insert_one(insight_dict)
        
        return {
            "success": True,
            "message": f"Generated {len(insights)} advanced insights",
            "insights": [insight.model_dump() for insight in insights]
        }
    except Exception as e:
        logger.error(f"Error generating insights: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()